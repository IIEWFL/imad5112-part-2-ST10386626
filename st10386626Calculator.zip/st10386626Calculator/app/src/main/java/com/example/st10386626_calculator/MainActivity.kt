package com.example.st10386626_calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.lang.ArithmeticException
import java.math.BigDecimal
import java.math.RoundingMode

class MainActivity : AppCompatActivity() {

    private var firstNumber: TextView? = null
    private var secondNumber: TextView? = null
    private var outputSolution: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        firstNumber = findViewById(R.id.firstNumber)
        secondNumber = findViewById(R.id.secondNumber)
        outputSolution = findViewById(R.id.outputSolution)

        val addButton = findViewById<Button>(R.id.addButton)
        val subtractButton = findViewById<Button>(R.id.subtractButton)
        val multiplyButton = findViewById<Button>(R.id.multiplyButton)
        val divideButton = findViewById<Button>(R.id.divideButton)

        addButton.setOnClickListener()
        {
            addition()
        }
        subtractButton.setOnClickListener()
        {
            subtraction()
        }
        multiplyButton.setOnClickListener()
        {
            multiplication()
        }
        divideButton.setOnClickListener()
        {
            division()
        }
    }

    private fun addition() {

        if (fieldIsValid()) {
            val firstDigit = firstNumber?.text.toString().trim().toBigDecimal()
            val secondDigit = secondNumber?.text.toString().trim().toBigDecimal()
            val result = firstDigit.add(secondDigit)
            outputSolution?.text = "$firstDigit + $secondDigit = $result"
        }

    }


    private fun subtraction() {
        if (fieldIsValid()) {
            val firstDigit = firstNumber?.text.toString().trim().toBigDecimal()
            val secondDigit = secondNumber?.text.toString().trim().toBigDecimal()
            val result = firstDigit.subtract(secondDigit)
            outputSolution?.text = "$firstDigit - $secondDigit = $result"
        }

    }


    private fun multiplication() {
        if (fieldIsValid()) {
            val firstDigit = firstNumber?.text.toString().trim().toBigDecimal()
            val secondDigit = secondNumber?.text.toString().trim().toBigDecimal()
            val result = firstDigit.multiply(secondDigit)
            outputSolution?.text = "$firstDigit x $secondDigit = $result"
        }

    }

    private fun division() {
        if (fieldIsValid()) {
            val firstDigit = firstNumber?.text.toString().trim().toBigDecimal()
            var secondDigit = secondNumber?.text.toString().trim().toBigDecimal()

            try {
                if (secondDigit == BigDecimal.ZERO) {
                    outputSolution?.text = "Cannot divide by ZERO."
                } else {
                    val result = firstDigit.divide(secondDigit, 2, RoundingMode.HALF_UP)
                    outputSolution?.text = result.toString()
                    outputSolution?.text = "$firstDigit / $secondDigit = $result"
                }
            } catch (e: ArithmeticException) {
                outputSolution?.text = "Error:${e.message}"
            }
        }
    }

    private fun fieldIsValid(): Boolean {
        var answer = true
        if (firstNumber?.text.toString().trim().isEmpty()) {
            firstNumber?.error = "Please enter a valid number!"
            answer = false
        }
        if (secondNumber?.text.toString().trim().isEmpty()) {
            secondNumber?.error = "Please enter a valid number!"
            answer = false
        }
        return answer

    }

}