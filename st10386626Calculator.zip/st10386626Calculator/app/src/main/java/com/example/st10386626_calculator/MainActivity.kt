package com.example.st10386626_calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.lang.ArithmeticException
import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.absoluteValue
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    private var firstNumber: TextView? = null
    private var secondNumber: TextView? = null
    private var outputSolution: TextView? = null
    private var squareAnswer: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        firstNumber = findViewById(R.id.firstNumber)
        secondNumber = findViewById(R.id.secondNumber)
        outputSolution = findViewById(R.id.outputSolution)
        squareAnswer = findViewById(R.id.squareAnswer)

        val addButton = findViewById<Button>(R.id.addButton)
        val subtractButton = findViewById<Button>(R.id.subtractButton)
        val multiplyButton = findViewById<Button>(R.id.multiplyButton)
        val divideButton = findViewById<Button>(R.id.divideButton)
        val squareRoot = findViewById<Button>(R.id.squareRoot)
        val powerButton = findViewById<Button>(R.id.powerButton)
        val clearButton = findViewById<Button>(R.id.clearButton)

        addButton.setOnClickListener()
        {
            addition()
        }
        subtractButton.setOnClickListener()
        {
            subtraction()
        }
        multiplyButton.setOnClickListener()
        {
            multiplication()
        }
        divideButton.setOnClickListener()
        {
            division()
        }
        squareRoot.setOnClickListener {
            square()
        }
        powerButton.setOnClickListener {
            power()
        }
        clearButton.setOnClickListener {
            clear()
        }
    }

    private fun addition() {

        if (fieldIsValid()) {
            val firstDigit = firstNumber?.text.toString().trim().toBigDecimal()
            val secondDigit = secondNumber?.text.toString().trim().toBigDecimal()
            val result = firstDigit.add(secondDigit)
            outputSolution?.text = "$firstDigit + $secondDigit = $result"
        }

    }


    private fun subtraction() {
        if (fieldIsValid()) {
            val firstDigit = firstNumber?.text.toString().trim().toBigDecimal()
            val secondDigit = secondNumber?.text.toString().trim().toBigDecimal()
            val result = firstDigit.subtract(secondDigit)
            outputSolution?.text = "$firstDigit - $secondDigit = $result"
        }

    }


    private fun multiplication() {
        if (fieldIsValid()) {
            val firstDigit = firstNumber?.text.toString().trim().toBigDecimal()
            val secondDigit = secondNumber?.text.toString().trim().toBigDecimal()
            val result = firstDigit.multiply(secondDigit)
            outputSolution?.text = "$firstDigit x $secondDigit = $result"
        }

    }

    private fun division() {
        if (fieldIsValid()) {
            val firstDigit = firstNumber?.text.toString().trim().toBigDecimal()
            var secondDigit = secondNumber?.text.toString().trim().toBigDecimal()

            try {
                if (secondDigit == BigDecimal.ZERO) {
                    outputSolution?.text = "Cannot divide by ZERO."
                } else {
                    val result = firstDigit.divide(secondDigit, 2, RoundingMode.HALF_UP)
                    outputSolution?.text = result.toString()
                    outputSolution?.text = "$firstDigit / $secondDigit = $result"
                }
            } catch (e: ArithmeticException) {
                outputSolution?.text = "Error:${e.message}"
            }
        }
    }

    private fun fieldIsValid(): Boolean {
        var answer = true
        if (firstNumber?.text.toString().trim().isEmpty()) {
            firstNumber?.error = "Please enter a valid number!"
            answer = false
        }
        if (secondNumber?.text.toString().trim().isEmpty()) {
            secondNumber?.error = "Please enter a valid number!"
            answer = false
        }
        return answer
    }

    private fun power() {
        if (fieldIsValid()) {
            val firstDigit = firstNumber?.text.toString().trim().toBigDecimal().toDouble()
            val secondDigit = secondNumber?.text.toString().trim().toBigDecimal().toInt()
            var result = 1.0

            for (i in 1..secondDigit) {
                result *= firstDigit
            }
            outputSolution?.text = "$firstDigit ^ $secondDigit = $result"
        }
    }

    //backup if the statement below proves too difficult
    /* private fun square() {
         if (fieldIsValid()) {
             val firstDigit = firstNumber?.text.toString().trim().toBigDecimal()
             val secondDigit = secondNumber?.text.toString().trim().toBigDecimal()

             if (squareIsNegative()) {
                 val sqrtResult = sqrt(firstDigit.toDouble())
                 val secondOutput = sqrt(secondDigit.toDouble())

                 outputSolution?.text = "sqrt($firstDigit) = $sqrtResult"
                 squareAnswer?.text = "sqrt($secondDigit) = $secondOutput"
             }
         }
     }
 */

    private fun square(): Boolean {
        if (fieldIsValid()) {
            val firstText = firstNumber?.text.toString().trim()
            val secondText = secondNumber?.text.toString().trim()

            val firstDigit = firstText.toDoubleOrNull()
            val secondDigit = secondText.toDoubleOrNull()

            if (firstDigit != null && secondDigit != null) {
                val sqrtResult = sqrtFun(firstDigit)
                val secondOutput = sqrtFun(secondDigit)

                outputSolution?.text = "sqrt($firstText) = $sqrtResult"
                squareAnswer?.text = "sqrt($secondText) = $secondOutput"
            } else {
                outputSolution?.text = "Invalid input entered"
                squareAnswer?.text = "Invalid input entered"
            }
        }
        return true
    }

    private fun sqrtFun(x: Double): String {
        return if (x >= 0) {
            sqrt(x).toString()
        } else {
            val result = sqrt(-x)
            "${String.format("%.2f", result)} i"
        }
    }

    private fun clear() {
        outputSolution?.text = ""
        squareAnswer?.text = ""
        firstNumber?.text = ""
        secondNumber?.text = ""
    }
}